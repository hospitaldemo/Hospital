package com.neuedu.hospital.service;

import com.neuedu.hospital.pojo.Login;

public interface LoginService {
    Login login(Login login);//登录
}
